#pragma once
#define GVPLUGIN_CONFIG_FILE "config8"
#define GVPLUGIN_VERSION 8
#define PACKAGE_BUGREPORT "https://gitlab.com/graphviz/graphviz/-/issues"
#define PACKAGE_NAME "graphviz"
#define PACKAGE_STRING "graphviz 13.0.1"
#define PACKAGE_TARNAME "graphviz"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "13.0.1"
